import torch
from torch import nn
import torch.nn.functional as F

# ---------------------- 3D Conv + ReLU ----------------------
class Conv3dReLU(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size, padding=0, stride=1, use_batchnorm=True):
        conv = nn.Conv3d(
            in_channels, out_channels, kernel_size, stride=stride,
            padding=padding, bias=not use_batchnorm
        )
        relu = nn.ReLU(inplace=True)
        bn = nn.BatchNorm3d(out_channels)
        super(Conv3dReLU, self).__init__(conv, bn, relu)

# ---------------------- Double Conv 3D ----------------------
class DoubleConv3D(nn.Module):
    def __init__(self, cin, cout):
        super(DoubleConv3D, self).__init__()
        self.conv = nn.Sequential(
            Conv3dReLU(cin, cout, 3, padding=1),
            Conv3dReLU(cout, cout, 3, padding=1, use_batchnorm=True)
        )

    def forward(self, x):
        return self.conv(x)

# ---------------------- DecoderBlock 3D ----------------------
class DecoderBlock3D(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True)
        self.conv1 = Conv3dReLU(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv2 = Conv3dReLU(out_channels, out_channels, kernel_size=3, padding=1)

    def forward(self, x, skip=None):
        x = self.up(x)
        if skip is not None:
            x = torch.cat([x, skip], dim=1)
        x = self.conv1(x)
        x = self.conv2(x)
        return x

# ---------------------- SegmentationHead 3D ----------------------
class SegmentationHead3D(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, upsampling=1):
        conv = nn.Conv3d(in_channels, out_channels, kernel_size=kernel_size, padding=kernel_size // 2)
        up = nn.Upsample(scale_factor=upsampling, mode='trilinear', align_corners=True) if upsampling > 1 else nn.Identity()
        super().__init__(conv, up)

# ---------------------- HGNN 层 ----------------------
class HGNN(nn.Module):
    def __init__(self, in_ch, n_out):
        super(HGNN, self).__init__()
        self.conv = nn.Linear(in_ch, n_out)
        self.bn = nn.BatchNorm1d(n_out)

    def forward(self, x, G):
        residual = x
        x = self.conv(x)
        x = G.matmul(x)
        x = F.relu(self.bn(x.permute(0,2,1).contiguous())).permute(0,2,1).contiguous() + residual
        return x

# ---------------------- HGNN_layer ----------------------
class HGNN_layer(nn.Module):
    def __init__(self, in_ch, node=None, K_neigs=None, kernel_size=5, stride=2):
        super(HGNN_layer, self).__init__()
        self.HGNN = HGNN(in_ch, in_ch)
        self.K_neigs = K_neigs

    def forward(self, x):
        # x shape: [B, N, C] for HGNN
        B, N, C = x.shape
        # 简化处理，直接构造单位矩阵作为 G
        G = torch.eye(N, device=x.device).unsqueeze(0).repeat(B,1,1)
        x = self.HGNN(x, G)
        return x

# ---------------------- HyperNet ----------------------
class HyperNet(nn.Module):
    def __init__(self, channel, node=28, K_neigs=None):
        super(HyperNet, self).__init__()
        self.HGNN_layer = HGNN_layer(channel, node=node, K_neigs=K_neigs)

    def forward(self, x):
        B, C, D, H, W = x.shape
        x = x.view(B, C, -1).permute(0,2,1).contiguous()  # B, N, C
        x = self.HGNN_layer(x)
        x = x.permute(0,2,1).contiguous().view(B, C, D, H, W)
        return x

# ---------------------- HyperEncoder ----------------------
class HyperEncoder(nn.Module):
    def __init__(self, channel=[512, 1024, 1024]):
        super(HyperEncoder, self).__init__()
        self.layer1 = HyperNet(channel[0], node=28, K_neigs=[1])
        self.layer2 = HyperNet(channel[1], node=14, K_neigs=[1])
        self.layer3 = HyperNet(channel[2], node=7, K_neigs=[1])

    def forward(self, features):
        f1, f2, f3 = features[-3:]  # 原版 encoder 的高层 feature
        f1 = self.layer1(f1)
        f2 = self.layer2(f2)
        f3 = self.layer3(f3)
        return [f1, f2, f3]

# ---------------------- ParallEncoder ----------------------
class ParallEncoder(nn.Module):
    def __init__(self, in_channels=1):
        super(ParallEncoder, self).__init__()
        self.encoder = nn.ModuleList([
            DoubleConv3D(in_channels, 64),
            DoubleConv3D(64, 128),
            DoubleConv3D(128, 256),
            DoubleConv3D(256, 512),
            DoubleConv3D(512, 1024)
        ])
        self.pool = nn.MaxPool3d(2)
        self.hyper_encoder = HyperEncoder()
        self.squeelayers = nn.ModuleList([
            nn.Conv3d(512*2, 512, 1),
            nn.Conv3d(1024*2, 1024, 1),
            nn.Conv3d(1024*2, 1024, 1)
        ])

    def forward(self, x):
        features = []
        skips = []
        for layer in self.encoder:
            x = layer(x)
            features.append(x)
            x = self.pool(x)
        hyper_features = self.hyper_encoder(features)
        skips.extend(features[:3])
        for i in range(3):
            skip = self.squeelayers[i](torch.cat([hyper_features[i], features[i+3]], dim=1))
            skips.append(skip)
        return skips

# ---------------------- Model 3D ----------------------
class Model(nn.Module):
    def __init__(self, in_channels=1, n_classes=6):
        super(Model, self).__init__()
        self.p_encoder = ParallEncoder(in_channels=in_channels)
        self.encoder_channels = [1024, 512, 256, 128, 64]

        self.decoder1 = DecoderBlock3D(self.encoder_channels[0]+self.encoder_channels[0], self.encoder_channels[1])
        self.decoder2 = DecoderBlock3D(self.encoder_channels[1]+self.encoder_channels[1], self.encoder_channels[2])
        self.decoder3 = DecoderBlock3D(self.encoder_channels[2]+self.encoder_channels[2], self.encoder_channels[3])
        self.decoder4 = DecoderBlock3D(self.encoder_channels[3]+self.encoder_channels[3], self.encoder_channels[4])

        self.seg_head2 = SegmentationHead3D(256, n_classes)
        self.seg_head3 = SegmentationHead3D(128, n_classes)
        self.seg_head4 = SegmentationHead3D(64, n_classes)
        self.seg_head5 = SegmentationHead3D(64, n_classes)

        self.decoder_final = DecoderBlock3D(64, 64)

    def forward(self, x):
        if x.size(1) == 1:
            x = x.repeat(1, 3, 1, 1, 1)
        skips = self.p_encoder(x)

        x1 = self.decoder1(skips[-1], skips[-2])
        x2 = self.decoder2(x1, skips[-3])
        x3 = self.decoder3(x2, skips[-4])
        x4 = self.decoder4(x3, skips[-5])
        x_final = self.decoder_final(x4, None)

        out2 = F.interpolate(self.seg_head2(x2), scale_factor=8, mode='trilinear', align_corners=True)
        out3 = F.interpolate(self.seg_head3(x3), scale_factor=4, mode='trilinear', align_corners=True)
        out4 = F.interpolate(self.seg_head4(x4), scale_factor=2, mode='trilinear', align_corners=True)
        logits = self.seg_head5(x_final)

        return out2, out3, out4, logits

# ---------------------- 测试 ----------------------
if __name__ == '__main__':
    model = Model(in_channels=1, n_classes=6)
    x = torch.randn(1, 1, 16, 224, 224)  # 示例 3D MRI: B, C, D, H, W
    out2, out3, out4, logits = model(x)
    print(out2.shape, out3.shape, out4.shape, logits.shape)
    print('Parameters (M):', sum(p.numel() for p in model.parameters())/1e6)
