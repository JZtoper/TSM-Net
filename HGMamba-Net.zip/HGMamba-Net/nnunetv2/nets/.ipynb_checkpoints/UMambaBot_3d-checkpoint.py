import numpy as np
import math
import torch
from torch import nn
from torch.nn import functional as F
from typing import Union, Type, List, Tuple

from nnunetv2.nets.model import Model as AHGNNModel  # AHGNN model.py
from dynamic_network_architectures.building_blocks.helper import get_matching_convtransp, get_matching_pool_op, maybe_convert_scalar_to_list, get_matching_instancenorm, convert_dim_to_conv_op
from dynamic_network_architectures.initialization.weight_init import init_last_bn_before_add_to_0
from nnunetv2.utilities.plans_handling.plans_handler import ConfigurationManager, PlansManager
from nnunetv2.utilities.network_initialization import InitWeights_He
from mamba_ssm import Mamba
from dynamic_network_architectures.building_blocks.residual import BasicBlockD
from torch.nn.modules.conv import _ConvNd
from torch.nn.modules.dropout import _DropoutNd
from torch.cuda.amp import autocast

# --------------------- Basic Blocks ---------------------

class UpsampleLayer(nn.Module):
    def __init__(self, conv_op, input_channels, output_channels, pool_op_kernel_size, mode='nearest'):
        super().__init__()
        self.conv = conv_op(input_channels, output_channels, kernel_size=1)
        self.pool_op_kernel_size = pool_op_kernel_size
        self.mode = mode

    def forward(self, x):
        x = F.interpolate(x, scale_factor=self.pool_op_kernel_size, mode=self.mode)
        x = self.conv(x)
        return x


class MambaLayer(nn.Module):
    def __init__(self, dim, d_state=16, d_conv=4, expand=2):
        super().__init__()
        self.dim = dim
        self.norm = nn.LayerNorm(dim)
        self.mamba = Mamba(d_model=dim, d_state=d_state, d_conv=d_conv, expand=expand)

    @autocast(enabled=False)
    def forward(self, x):
        if x.dtype == torch.float16:
            x = x.type(torch.float32)
        B, C = x.shape[:2]
        n_tokens = x.shape[2:].numel()
        img_dims = x.shape[2:]
        x_flat = x.reshape(B, C, n_tokens).transpose(-1, -2)
        x_norm = self.norm(x_flat)
        x_mamba = self.mamba(x_norm)
        out = x_mamba.transpose(-1, -2).reshape(B, C, *img_dims)
        return out


class HyperGraphLayer(nn.Module):
    """可选 HyperGraph 模块，用于 encoder 最后特征增强"""
    def __init__(self, in_channels):
        super().__init__()
        self.ahgnn = AHGNNModel(in_channels=in_channels)

    def forward(self, x):
        B, C, D, H, W = x.shape
        x_flat = x.view(B, C, -1).transpose(1, 2)
        x_out = self.ahgnn(x_flat)
        x_out = x_out.transpose(1, 2).view(B, C, D, H, W)
        return x_out


class BasicResBlock(nn.Module):
    def __init__(self, conv_op, input_channels, output_channels, norm_op, norm_op_kwargs,
                 kernel_size=3, padding=1, stride=1, use_1x1conv=False, nonlin=nn.LeakyReLU, nonlin_kwargs={'inplace': True}):
        super().__init__()
        self.conv1 = conv_op(input_channels, output_channels, kernel_size, stride=stride, padding=padding)
        self.norm1 = norm_op(output_channels, **norm_op_kwargs)
        self.act1 = nonlin(**nonlin_kwargs)

        self.conv2 = conv_op(output_channels, output_channels, kernel_size, padding=padding)
        self.norm2 = norm_op(output_channels, **norm_op_kwargs)
        self.act2 = nonlin(**nonlin_kwargs)

        if use_1x1conv:
            self.conv3 = conv_op(input_channels, output_channels, kernel_size=1, stride=stride)
        else:
            self.conv3 = None

    def forward(self, x):
        y = self.conv1(x)
        y = self.act1(self.norm1(y))
        y = self.norm2(self.conv2(y))
        if self.conv3:
            x = self.conv3(x)
        y += x
        return self.act2(y)

# --------------------- Encoder ---------------------

class UNetResEncoder(nn.Module):
    def __init__(self, input_channels, n_stages, features_per_stage, conv_op, kernel_sizes, strides, n_blocks_per_stage,
                 conv_bias=False, norm_op=None, norm_op_kwargs=None, nonlin=None, nonlin_kwargs=None,
                 return_skips=False, stem_channels=None, pool_type='conv'):
        super().__init__()
        if isinstance(kernel_sizes, int):
            kernel_sizes = [kernel_sizes] * n_stages
        if isinstance(features_per_stage, int):
            features_per_stage = [features_per_stage] * n_stages
        if isinstance(n_blocks_per_stage, int):
            n_blocks_per_stage = [n_blocks_per_stage] * n_stages
        if isinstance(strides, int):
            strides = [strides] * n_stages

        self.conv_op = conv_op
        self.norm_op = norm_op
        self.norm_op_kwargs = norm_op_kwargs
        self.nonlin = nonlin
        self.nonlin_kwargs = nonlin_kwargs
        self.conv_bias = conv_bias
        self.kernel_sizes = kernel_sizes

        pool_op = get_matching_pool_op(conv_op, pool_type=pool_type) if pool_type != 'conv' else None

        self.conv_pad_sizes = [[k // 2 for k in krnl] for krnl in kernel_sizes]
        stem_channels = features_per_stage[0]

        self.stem = nn.Sequential(
            BasicResBlock(conv_op, input_channels, stem_channels, norm_op, norm_op_kwargs,
                          kernel_size=kernel_sizes[0], padding=self.conv_pad_sizes[0], stride=1,
                          nonlin=nonlin, nonlin_kwargs=nonlin_kwargs, use_1x1conv=True),
            *[BasicBlockD(conv_op, stem_channels, stem_channels, kernel_size=kernel_sizes[0], stride=1,
                          conv_bias=conv_bias, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs,
                          nonlin=nonlin, nonlin_kwargs=nonlin_kwargs) for _ in range(n_blocks_per_stage[0]-1)]
        )

        input_channels = stem_channels
        stages = []
        for s in range(n_stages):
            stage = nn.Sequential(
                BasicResBlock(conv_op, input_channels, features_per_stage[s], norm_op, norm_op_kwargs,
                              kernel_size=kernel_sizes[s], padding=self.conv_pad_sizes[s], stride=strides[s],
                              use_1x1conv=True, nonlin=nonlin, nonlin_kwargs=nonlin_kwargs),
                *[BasicBlockD(conv_op, features_per_stage[s], features_per_stage[s], kernel_size=kernel_sizes[s],
                              stride=1, conv_bias=conv_bias, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs,
                              nonlin=nonlin, nonlin_kwargs=nonlin_kwargs) for _ in range(n_blocks_per_stage[s]-1)]
            )
            stages.append(stage)
            input_channels = features_per_stage[s]

        self.stages = nn.Sequential(*stages)
        self.output_channels = features_per_stage
        self.strides = [maybe_convert_scalar_to_list(conv_op, i) for i in strides]
        self.return_skips = return_skips

    def forward(self, x):
        if self.stem is not None:
            x = self.stem(x)
        ret = []
        for s in self.stages:
            x = s(x)
            ret.append(x)
        return ret if self.return_skips else ret[-1]

# --------------------- Decoder ---------------------

class UNetResDecoder(nn.Module):
    def __init__(self, encoder, num_classes, n_conv_per_stage, deep_supervision, nonlin_first=False):
        super().__init__()
        self.deep_supervision = deep_supervision
        self.encoder = encoder
        self.num_classes = num_classes
        n_stages_encoder = len(encoder.output_channels)
        if isinstance(n_conv_per_stage, int):
            n_conv_per_stage = [n_conv_per_stage]*(n_stages_encoder-1)
        stages, upsample_layers, seg_layers = [], [], []
        for s in range(1, n_stages_encoder):
            input_features_below = encoder.output_channels[-s]
            input_features_skip = encoder.output_channels[-(s+1)]
            stride_for_upsampling = encoder.strides[-s]

            upsample_layers.append(UpsampleLayer(encoder.conv_op, input_features_below, input_features_skip,
                                                 stride_for_upsampling, mode='nearest'))

            stages.append(nn.Sequential(
                BasicResBlock(encoder.conv_op, 2*input_features_skip, input_features_skip,
                              encoder.norm_op, encoder.norm_op_kwargs, kernel_size=encoder.kernel_sizes[-(s+1)],
                              padding=encoder.conv_pad_sizes[-(s+1)], stride=1, use_1x1conv=True,
                              nonlin=encoder.nonlin, nonlin_kwargs=encoder.nonlin_kwargs),
                *[BasicBlockD(encoder.conv_op, input_features_skip, input_features_skip,
                              kernel_size=encoder.kernel_sizes[-(s+1)], stride=1, conv_bias=encoder.conv_bias,
                              norm_op=encoder.norm_op, norm_op_kwargs=encoder.norm_op_kwargs,
                              nonlin=encoder.nonlin, nonlin_kwargs=encoder.nonlin_kwargs)
                  for _ in range(n_conv_per_stage[s-1]-1)]
            ))
            seg_layers.append(encoder.conv_op(input_features_skip, num_classes, 1, 1, 0, bias=True))

        self.stages = nn.ModuleList(stages)
        self.upsample_layers = nn.ModuleList(upsample_layers)
        self.seg_layers = nn.ModuleList(seg_layers)

    def forward(self, skips):
        lres_input = skips[-1]
        seg_outputs = []
        for s in range(len(self.stages)):
            x = self.upsample_layers[s](lres_input)
            x = torch.cat((x, skips[-(s+2)]), 1)
            x = self.stages[s](x)
            if self.deep_supervision:
                seg_outputs.append(self.seg_layers[s](x))
            elif s == (len(self.stages)-1):
                seg_outputs.append(self.seg_layers[-1](x))
            lres_input = x
        seg_outputs = seg_outputs[::-1]
        return seg_outputs[0] if not self.deep_supervision else seg_outputs

# --------------------- UMambaBot ---------------------

class UMambaBot(nn.Module):
    def __init__(self, input_channels, n_stages, features_per_stage, conv_op, kernel_sizes, strides,
                 n_conv_per_stage, num_classes, n_conv_per_stage_decoder,
                 conv_bias=False, norm_op=None, norm_op_kwargs=None,
                 dropout_op=None, dropout_op_kwargs=None,
                 nonlin=None, nonlin_kwargs=None,
                 deep_supervision=False, stem_channels=None,
                 use_hypergraph=True):
        super().__init__()

        if isinstance(n_conv_per_stage, int):
            n_conv_per_stage = [n_conv_per_stage]*n_stages
        if isinstance(n_conv_per_stage_decoder, int):
            n_conv_per_stage_decoder = [n_conv_per_stage_decoder]*(n_stages-1)

        self.encoder = UNetResEncoder(input_channels, n_stages, features_per_stage, conv_op,
                                      kernel_sizes, strides, n_conv_per_stage,
                                      conv_bias, norm_op, norm_op_kwargs,
                                      nonlin, nonlin_kwargs, return_skips=True,
                                      stem_channels=stem_channels)

        self.use_hypergraph = use_hypergraph
        if use_hypergraph:
            self.hypergraph_layer = HyperGraphLayer(features_per_stage[-1])

        self.decoder = UNetResDecoder(self.encoder, num_classes, n_conv_per_stage_decoder, deep_supervision)

    def forward(self, x):
        skips = self.encoder(x)
        if self.use_hypergraph:
            skips[-1] = self.hypergraph_layer(skips[-1])
        return self.decoder(skips)

# --------------------- Factory Function ---------------------

def get_umamba_bot_3d_from_plans(plans_manager: PlansManager,
                                 dataset_json: dict,
                                 configuration_manager: ConfigurationManager,
                                 num_input_channels: int,
                                 deep_supervision: bool = True,
                                 use_hypergraph: bool = True):
    num_stages = len(configuration_manager.conv_kernel_sizes)
    dim = len(configuration_manager.conv_kernel_sizes[0])
    conv_op = convert_dim_to_conv_op(dim)

    label_manager = plans_manager.get_label_manager(dataset_json)

    features_per_stage = [min(configuration_manager.UNet_base_num_features * 2 ** i,
                              configuration_manager.unet_max_num_features) for i in range(num_stages)]

    kwargs = {
        'conv_bias': True,
        'norm_op': get_matching_instancenorm(conv_op),
        'norm_op_kwargs': {'eps': 1e-5, 'affine': True},
        'dropout_op': None, 'dropout_op_kwargs': None,
        'nonlin': nn.LeakyReLU, 'nonlin_kwargs': {'inplace': True},
        'deep_supervision': deep_supervision,
        'use_hypergraph': use_hypergraph
    }

    model = UMambaBot(
        input_channels=num_input_channels,
        n_stages=num_stages,
        features_per_stage=features_per_stage,
        conv_op=conv_op,
        kernel_sizes=configuration_manager.conv_kernel_sizes,
        strides=configuration_manager.pool_op_kernel_sizes,
        n_conv_per_stage=configuration_manager.n_conv_per_stage_encoder,
        num_classes=label_manager.num_segmentation_heads,
        n_conv_per_stage_decoder=configuration_manager.n_conv_per_stage_decoder,
        **kwargs
    )
    model.apply(InitWeights_He(1e-2))
    return model
